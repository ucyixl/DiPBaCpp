#ifndef _profRegr_POST_PROCESS
#define _profRegr_POST_PROCESS

#include <Rcpp.h>

RcppExport SEXP calcDisSimMat(SEXP fileName, SEXP nSweeps, SEXP nBurn, SEXP nFilter,SEXP nSubjects,SEXP nPredictSubjects);

#endif
